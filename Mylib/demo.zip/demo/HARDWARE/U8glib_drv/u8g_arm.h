#ifndef _U8G_ARM_H
#define _U8G_ARM_H
//adjust this path:
#include "u8g2.h"
#include "u8x8.h"

#include "sys.h"


#define MODE_DATA 0XFA
#define MODE_CMD  0XF8

//#define CS_ON()        GPIO_SetBits(GPIOA, GPIO_Pin_7)   //�����ѧ�ѧ�ߧ��� CS
//#define CS_OFF()       GPIO_ResetBits(GPIOA, GPIO_Pin_7)

/*******����SPI********/
#define SW_SPI //����SPI

#ifdef SW_SPI 
	#define DIN PAout(5)  //  MOSI-->R/W ���ݴ�������
	#define CLK PAout(6)  //  SCLK-->E ʱ������
	#define CS  PAout(7) 	//  CS-->RS Ƭѡ����

  #define CS_ON()    CS=1  //  GPIO_SetBits(GPIOA, GPIO_Pin_7)  
  #define CS_OFF()   CS=0  //  GPIO_ResetBits(GPIOA, GPIO_Pin_7)
#endif

/*******Ӳ��SPI********/
//#define HW_SPI //Ӳ��SPI

#ifdef SW_SPI 
//*************************************************************************
void WS2811_delay(unsigned int delay_num);
void SW_SPI_Init(void);
void HW_SPI_Init(void);
void SPI_SendData(uint8_t data);
void SPI_WriteByte(uint8_t data, uint8_t mode);

//void TP_Write_Byte(u8 num);

//uint8_t u8g_com_hw_spi_fn(u8g_t *u8g, uint8_t msg, uint8_t arg_val, void *arg_ptr);

uint8_t u8g2_gpio_and_delay_stm32(U8X8_UNUSED u8x8_t *u8x8, U8X8_UNUSED uint8_t msg, U8X8_UNUSED uint8_t arg_int, U8X8_UNUSED void *arg_ptr);

#endif
#endif
