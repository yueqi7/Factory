#ifndef __KEY_H_
#define __KEY_H_
#include <sys.h>



void Key_Init(void);
#endif
